setwd("C:\\Users\\IT24104211\\Desktop\\IT24104211")
getwd()


#1
branch_data <- read.table("Exercise.txt", header = TRUE, sep=",")
fix(branch_data)
attach(branch_data)

#2)
str(branch_data)



#3)
boxplot(branch_data$Sales, 
        main = "Boxplot for Sales", 
        ylab = "Sales",
        col = "lightblue")

# Add grid
grid()


#4)
# Five number summary
summary(branch_data$Advertising)

# Just min, Q1, median, Q3, max
fivenum(branch_data$Advertising)

# IQR
IQR(branch_data$Advertising)


#5)
# Function to detect outliers
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- IQR(x)
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

# Check for outliers in Years variable
find_outliers(branch_data$Years)
